package org.zerock.controller;

import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.log4j.Log4j;

@RequestMapping("/includes/*")
@Log4j
public class Controller {
	
}
